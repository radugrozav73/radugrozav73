<template>
    <div>
        <List />
    </div>
</template>

<script>
import Navbar from "./smallcomponents/navbar/Navbar";
import List from "./list/SurveysList";
export default {
    components:{
        List,
    },
}
</script>

<style scoped>
</style>