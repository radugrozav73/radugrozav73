<template>
    <div >
        <HomeInfo />
    </div>
</template>

<script>
import Navbar from "./smallcomponents/navbar/Navbar";
import HomeInfo from "./smallcomponents/home/HomeInfo";
    export default {
        components:{
            HomeInfo
        },
    }
</script>
